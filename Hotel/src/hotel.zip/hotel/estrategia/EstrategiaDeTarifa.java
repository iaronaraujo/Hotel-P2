package hotel.estrategia;




/**
 * @author Luiz
 */
public interface EstrategiaDeTarifa {

    double calculaTotalGasto(double total) throws Exception;
}
