package hotel.estrategia;

import java.io.Serializable;



/**
 *
 * @author luiz
 */
public class Simples implements EstrategiaDeTarifa, Serializable {

    double contaCheckout;
    double tarifaSimples = 0; // Pode ser alterada - DEFAULT = 0
    double valorTotalServicos;

    /**
     *
     * @param total Valor total acumulado no custo dos servicos utilizados
     * @return contaCheckout Valor final do preço já tendo aplicada a taxa de
     * acordo com a estação
     * @throws Exception Para valor total dos servicos nulo ou negativo
     */
    @Override
    public double calculaTotalGasto(double total) throws Exception {

        if (total <= 0) {
            throw new Exception("Preco total dos servicos consumidos nao pode ser nulo ou negativo");
        }

        contaCheckout = total + (tarifaSimples * total);

        return contaCheckout;
    }

    /**
     * @param tarifaSimples Define a taxa de tarifação sobre o valor total a ser
     * pago no período de tarifação simples
     */
    public void setTarifaSimples(double tarifaSimples) throws Exception {

        if (Math.abs(tarifaSimples) > 1) {
            throw new Exception("Valor de tarifa invalido");
        }

        this.tarifaSimples = tarifaSimples;
    }

    /**
     * @return Tarifa aplicada no preço sobre servicos no periodo de tarifação
     * simples
     */
    public double getTarifaSimples() {
        return tarifaSimples;
    }
}
