package hotel.estrategia;

import java.io.Serializable;



/**
 *
 * @author luiz
 */
public class BaixaEstacao implements EstrategiaDeTarifa, Serializable {

    double contaCheckout;
    double tarifaBaixaEstacao = -0.10; // Desconto de 10% na baixa estação - DEFAULT
    double valorTotalServicos;

    /**
     *
     * @param total Valor total acumulado no custo dos servicos utilizados
     * @return contaCheckout Valor final do preço já tendo aplicada a taxa de
     * acordo com a estação
     * @throws Exception Para valor total dos servicos nulo ou negativo
     */
    @Override
    public double calculaTotalGasto(double total) throws Exception {

        if (total <= 0) {
            throw new Exception("Preco total dos servicos consumidos nao pode ser nulo ou negativo");
        }

        contaCheckout = total + (tarifaBaixaEstacao * total);

        return contaCheckout;
    }

    /**
     * @return Tarifa aplicada no preço sobre servicos no periodo de baixa
     * estação
     */
    public double getTarifaBaixaEstacao() {
        return tarifaBaixaEstacao;
    }

    /**
     * @param tarifaBaixaEstacao Define a taxa de tarifação sobre o valor total
     * a ser pago no período de baixa estação
     */
    public void setTarifaBaixaEstacao(double tarifaBaixaEstacao) throws Exception {

        if (Math.abs(tarifaBaixaEstacao) > 1) {
            throw new Exception("Valor de tarifa invalido");
        }

        this.tarifaBaixaEstacao = tarifaBaixaEstacao;
    }
}
