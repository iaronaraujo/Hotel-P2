package hotel.estrategia;

import java.io.Serializable;





/**
 *
 * @author luiz
 */
public class SaoJoao extends Simples implements Serializable {

    double contaCheckout;
    double tarifaSaoJoao = 0.10; // Acréscimo de 10% no São João - DEFAULT
    double valorTotalServicos;

    /**
     *
     * @param total Valor total acumulado no custo dos servicos utilizados
     * @return contaCheckout Valor final do preço já tendo aplicada a taxa de
     * acordo com a estação
     * @throws Exception Para valor total dos servicos nulo ou negativo
     */
    @Override
    public double calculaTotalGasto(double total) throws Exception {

        if (total <= 0) {
            throw new Exception("Preco total dos servicos consumidos nao pode ser nulo ou negativo");
        }

        contaCheckout = total + (tarifaSaoJoao * total);

        return contaCheckout;
    }

    /**
     * @param tarifaSaoJoao Define a taxa de tarifação sobre o valor total a ser
     * pago no período de São João
     */
    public void setTarifaSaoJoao(double tarifaSaoJoao) throws Exception {

        if (Math.abs(tarifaSaoJoao) > 1) {
            throw new Exception("Valor de tarifa invalido");
        }

        this.tarifaSaoJoao = tarifaSaoJoao;
    }

    /**
     * @return Tarifa aplicada no preço sobre servicos no periodo de São João
     */
    public double getTarifaSaoJoao() {
        return tarifaSaoJoao;
    }
}
