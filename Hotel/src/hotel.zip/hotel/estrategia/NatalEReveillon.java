package hotel.estrategia;

import java.io.Serializable;



/**
 *
 * @author luiz
 */
public class NatalEReveillon implements EstrategiaDeTarifa, Serializable {

    double contaCheckout;
    double tarifaNatalEReveillon = 0.50; // Acréscimo de 50% no Natal e Reveillon - DEFAULT
    double valorTotalServicos;

    /**
     *
     * @param total Valor total acumulado no custo dos servicos utilizados
     * @return contaCheckout Valor final do preço já tendo aplicada a taxa de
     * acordo com a estação
     * @throws Exception Para valor total dos servicos nulo ou negativo
     */
    @Override
    public double calculaTotalGasto(double total) throws Exception {

        if (total <= 0) {
            throw new Exception("Preco total dos servicos consumidos nao pode ser nulo ou negativo");
        }

        contaCheckout = total + (tarifaNatalEReveillon * total);

        return contaCheckout;
    }

    /**
     *
     * @param tarifaNatalEReveillon Define a taxa de tarifação sobre o valor
     * total a ser pago no período de natal e reveillon
     */
    public void setTarifaNatalEReveillon(double tarifaNatalEReveillon) throws Exception {

        if (Math.abs(tarifaNatalEReveillon) > 1) {
            throw new Exception("Valor de tarifa invalido");
        }

        this.tarifaNatalEReveillon = tarifaNatalEReveillon;
    }

    /**
     * @return Tarifa aplicada no preço sobre servicos no natal e reveillon
     */
    public double getTarifaNatalEReveillon() {
        return tarifaNatalEReveillon;
    }
}
