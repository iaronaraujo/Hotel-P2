package hotel.servicos;

import hotel.utilitarios.GerenciadorDePrecos;

import java.io.Serializable;

/**
 *
 * @author luiz
 */
public class Babysitting implements Servico, Serializable {

    /*  Seguinte iaron.... provavelmente não vai funcionar como deve aki.
     *  Ta sem os treco q precisa de calendar.
     */
    private int horasSolicitadas;
    private int horasEmValorDobrado;
    private String descricao;
    private final double horaNormal;
    private final double horaDobrada;
    public static final String nomeServico = "Babysitting";

    /**
     *
     * @param horasSolicitadas Quantidade de horas de serviço solicitadas(int)
     * @param horasEmValorDobrado Quantidade das horas solicitadas que são de
     * valor dobrado(int)
     * @param descricao Descrição do serviço(String)
     * @throws Exception Para horasSolicitadas menor ou igual a zero Para
     * horasEmValorDobradoo menor que zero ou maior que horasSolicitadas Para
     * descrição nula ou vazia
     */
    public Babysitting(int horasSolicitadas, int horasEmValorDobrado, String descricao) throws Exception {

        if (horasSolicitadas <= 0) {
            throw new Exception("Quantidade de horas inválida");
        }
        
        
        if (horasEmValorDobrado < 0 || horasEmValorDobrado > horasSolicitadas) {
            throw new Exception("Quantidade de horas em valor dobrado inválida");
        }
        
       
        if (descricao == "" || descricao == null) {
            throw new Exception("Descricao inválida");
        }

        this.horasSolicitadas = horasSolicitadas;
        this.horasEmValorDobrado = horasEmValorDobrado;
        this.descricao = descricao;
        this.horaNormal = GerenciadorDePrecos.getPrecoBabysitHoraNormal();
        this.horaDobrada = GerenciadorDePrecos.getPrecoBabysitHoraDobrada();
    }

    /**
     * Calcula preco de acordo com a quantidade de horas requisitadas e o
     * horario relativo a essas
     *
     * @return double total Preco total do serviço
     */
    @Override
    public double calculaPreco() {
        double total;
        total = horaNormal * (horasSolicitadas - horasEmValorDobrado);
        total += horaDobrada * horasEmValorDobrado;

        return total;
    }

    /**
     * Retorna a quantidade de horas de serviço solicitadas
     *
     * @return int horasSolicitadas
     */
    public int getHorasSolicitadas() {
        return horasSolicitadas;
    }

    /**
     * Atualiza a quantidade de horas requisitadas
     *
     * @param qntHoras Quantidade de horas de serviço
     * @throws Exception Para qntHoras menor ou igual a zero
     */
    public void setHorasSolicitadas(int qntHoras) throws Exception {
        if (qntHoras <= 0) {
            throw new Exception("Quantidade de horas inválida");
        }
        this.horasSolicitadas = qntHoras;
    }

    /**
     * Retorna a quantidade de horas requisitadas de valor dobrado
     *
     * @return horasEmValorDobrado
     */
    public int getHorasEmValorDobrado() {
        return horasEmValorDobrado;
    }

    /**
     *
     * @param horasValorDobrado
     * @throws Exception Para horasValorDobrado menor que zero Para
     * hoasValorDobrado maior que horasSolicitadas
     */
    public void setHorasEmValorDobrado(int horasValorDobrado) throws Exception {

        if (horasValorDobrado < 0 || horasValorDobrado > horasSolicitadas) {
            throw new Exception("Quantidade de horas inválida");
        }

        this.horasEmValorDobrado = horasValorDobrado;
    }

    /**
     * Retorna a string de descrição do servico
     *
     * @return String descricao
     */
    @Override
	public String getDescricao() {
        return descricao;
    }

    /**
     * Atualiza a descrição do serviço
     *
     * @param descr Nova descrição
     * @throws Exception Para descr vazia ou nula
     */
    public void setDescricao(String descr) throws Exception {
        if (descr.equals("") || descr.equals(null)) {
            throw new Exception("Descrição inválida");
        }
        descricao = descr;
    }

}
