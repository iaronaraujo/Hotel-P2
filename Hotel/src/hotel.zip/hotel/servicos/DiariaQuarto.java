package hotel.servicos;

import hotel.utilitarios.Quarto;
import hotel.utilitarios.QuartoExtensivel;

import java.io.Serializable;

/**
 *
 * @author luiz
 */
public class DiariaQuarto implements Servico, Serializable {

    private final Quarto quartoDoHotel;
    private int qDeDias;
    private String descricao;

	public static final String nomeServico = "Quarto";

    /**
     *
     * @param quartoDoHotel Objeto do tipo quarto que representa o quarto do
     * hotel a ser occupado
     * @param qDeDias Quantidade de dias da estadia(do alugel do quarto)
     * @param descricao Descrição do servico oferecido
     * @throws Exception Para quartoDoHotel fornecido nulo Para aDeDias
     * fornecida nula ou negativa Para descrição nula ou vazia Para quarto
     * ocupado
     */
    public DiariaQuarto(Quarto quartoDoHotel, int qDeDias, String descricao) throws Exception {

        if (quartoDoHotel == null) {
            throw new Exception("Quarto nao pode ser nulo");
        }
        if (qDeDias <= 0) {
            throw new Exception("Quantidade de dias invalida");
        }
        if (descricao == null || descricao.equals("")) {
            throw new Exception("Descricao invalida");
        }

        this.descricao = descricao;
        this.quartoDoHotel = quartoDoHotel;
        this.qDeDias = qDeDias;
    }
    
    /**
     *
     * @return soma total do preço das diárias
     */
    @Override
    public double calculaPreco() {
        return qDeDias * quartoDoHotel.getPrecoDiaria();
    }

    /**
     *
     * @return quantidade de dias de estadia (diárias)
     */
    public int getQDeDias() {
        return qDeDias;
    }

    /**
     * Atualiza a quantidade de diarias reservadas
     *
     * @param novaQDeDias novo numero de diarias
     * @throws Exception para quantidade de dias nula ou negativa
     */
    public void setQDeDias(int novaQDeDias) throws Exception {

        if (novaQDeDias <= 0) {
            throw new Exception("Numero de dias inválido.");
        }

        this.qDeDias = novaQDeDias;
    }

    /**
     *
     * @return descriçao da reserva/serviço
     */
    @Override
	public String getDescricao() {
        return descricao;
    }

    /**
     * Altera a descriçao do servico prestado
     *
     * @param novaDescr
     * @throws Exception para descriçao - string - nula ou vazia
     */
    public void setDescricao(String novaDescr) throws Exception {

        if (novaDescr.equals("") || novaDescr.equals(null)) {
            throw new Exception("Descrição invalida");
        }

        this.descricao = novaDescr;
    }
    
    public int getCamasExtras() {
    	if (QuartoExtensivel.class.isAssignableFrom(quartoDoHotel.getClass())) {
    		return ((QuartoExtensivel)quartoDoHotel).getQCamasExtras();
    	}
    	return 0;
    }
    /*
    public String getTipo() {
    	if (quartoDoHotel instanceof QuartoExecutivoDuplo) return ((QuartoExecutivoDuplo) quartoDoHotel).nomeQuarto;
    	else if (quartoDoHotel instanceof QuartoExecutivoSimples);
    	else if (quartoDoHotel instanceof QuartoExecutivoTriplo);
    	else if (quartoDoHotel instanceof QuartoLuxoDuplo);
    	else if (quartoDoHotel instanceof QuartoLuxoSimples);
    	if (QuartoExtensivel.class.isAssignableFrom(quartoDoHotel.getClass())){
    		if (quartoDoHotel instanceof QuartoExecutivoDuplo);
    	}
    }
    */
}
