package hotel.servicos;

import hotel.utilitarios.Carro;
import hotel.utilitarios.CarroDeLuxo;
import hotel.utilitarios.CarroExecutivo;
import hotel.utilitarios.GerenciadorDePrecos;

import java.io.Serializable;

/**
 *
 * @author luiz
 */
public class AluguelDeCarro implements Servico, Serializable {

    private final int diasDeAluguel;
    private Carro carroAlugado;
    private boolean isTanqueCheio;
    private boolean temSeguro;
	private String descricao;
    private double total;
	public static final String nomeServico = "Aluguel de carro";

    /**
     *
     * @param carroAlugado Objeto do tipo carro que representa o carro alugado
     * @param diasDeAluguel Quantidade de dias de aluguel do carro
     * @param isTanqueCheio Boolean que determina o adicional de tanque cheio
     * @param temSeguro Boolean que determina o adicional de seguro do carro
     * @param descricao Descrição do servico relacionado
     * @throws Exception Para quantidade de dias inválida(Nula ou negativa) Para
     * descrição nula ou vazia
     */
    public AluguelDeCarro(Carro carroAlugado, int diasDeAluguel, boolean isTanqueCheio, boolean temSeguro, String descricao) throws Exception {
        /*             isso aqui faz sentido???*/
                
         if(carroAlugado == null)
         throw new Exception("Carro nao pode ser nulo");
         
    	
        if (diasDeAluguel <= 0) {
            throw new Exception("Quantidade de dias invalida");
        }

        if (descricao == null || descricao == "") {
            throw new Exception("Descricao invalida");
        }

        this.carroAlugado = carroAlugado;
        this.diasDeAluguel = diasDeAluguel;
        this.isTanqueCheio = isTanqueCheio;
        this.temSeguro = temSeguro;
        this.descricao = descricao;
    }

    /**
     * Calcula o preço total do aluguel de carro em funcao da quantidade de dias
     *
     * @return double total preco do total do aluguel
     */
    @Override
    public double calculaPreco() {
        total += carroAlugado.precoDeAluguel() * diasDeAluguel;

        if (isTanqueCheio) {
            total += GerenciadorDePrecos.getPrecoDeTanqueCheio();
        }
        if (temSeguro) {
            total += GerenciadorDePrecos.getPrecoDeSeguro();
        }

        return total;
    }

    @Override
	public String getDescricao() {
        return descricao;
    }

    /* 
     * oq supostamente devo documentar aqui?? XD        
     */
    // O servico devia mesmo ter uma descrição? pensei q poderia ser do objeto utilizado no serviço no caso...
    public void setDescricao(String descricao) throws Exception {

        if (descricao.equals("") || descricao.equals(null)) {
            throw new Exception("Descrição inválida.");
        }

        this.descricao = descricao;
    }

    /**
     *
     * @return o preço do valor para alugar o carro com tanque cheio
     */
    public static double getPrecoDeTanqueCheio() {
        return GerenciadorDePrecos.getPrecoDeTanqueCheio();
    }

    /**
     *
     * @return preço para alugar o carro com seguro
     */
    public static double getPrecoDeSeguro() {
        return GerenciadorDePrecos.getPrecoDeSeguro();
    }

    /**
     *
     * @return Carro carroAlugado objeto do tipo carro oferecido pelo serviço
     */
    public Carro getCarroAlugado() {
        return carroAlugado;
    }

	public boolean isTanqueCheio() {
		return isTanqueCheio;
	}

	public boolean isTemSeguro() {
		return temSeguro;
	}
	
	public String getTipo() {
		if (carroAlugado instanceof CarroDeLuxo) return CarroDeLuxo.nomeServico;
		else return CarroExecutivo.nomeServico;
	}
	
	public void setTanqueCheio(boolean isTanqueCheio) {
		this.isTanqueCheio = isTanqueCheio;
	}

	public void setTemSeguro(boolean temSeguro) {
		this.temSeguro = temSeguro;
	}
	
	public void setCarroAlugado(Carro novoCarroAlugado) {
		this.carroAlugado = novoCarroAlugado;
	}
}
