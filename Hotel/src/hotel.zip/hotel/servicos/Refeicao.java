package hotel.servicos;

import java.io.Serializable;

public class Refeicao implements Servico, Serializable {

    private double valorDaRefeicao;
    private String descricao;
    public static final String nomeServico = "Refeição";

    /**
     *
     * @param valorDaRefeicao Valor da refeição pedida
     * @param descricao descrição do prato/da refeição pedido(a)
     * @throws Exception Para preço(valorDaRefeicao) nulo ou negativo Para
     * descrição nula ou vazia
     */
    public Refeicao(double valorDaRefeicao, String descricao) throws Exception {

        if (valorDaRefeicao <= 0) {
            throw new Exception("Preco invalido");
        }

        if (descricao == null || descricao.equals("")) {
            throw new Exception("Nome invalido");
        }

        this.valorDaRefeicao = valorDaRefeicao;
        this.descricao = descricao;
    }

    public void setValorDaRefeicao(double valorDaRefeicao) {
		this.valorDaRefeicao = valorDaRefeicao;
	}

	/**
     *
     * @return double valorDaRefeicao valor da refeição pedida
     */
    @Override
    public double calculaPreco() {
        return valorDaRefeicao;
    }

    /**
     *
     * @return String descricao descrição darefeição pedida
     */
    @Override
	public String getDescricao() {
        return descricao;
    }
    
    /**
     * 
     * @return double o valor da refeicao
     */
    public double getValorDaRefeicao() {
    	return valorDaRefeicao;
    }

    /**
     * Altera a descrição da refeição em função de um parâmetro de "nova
     * descrição"
     *
     * @param descricao Uma nova descrição para a refeição
     * @throws Exception Para um parametro de descrição nula ou vazia
     */
    public void setDescricao(String novaDescricao) throws Exception {
        if (novaDescricao.equals("") || novaDescricao.equals(null)) {
            throw new Exception("Descrição inválida.");
        }
        this.descricao = novaDescricao;
    }
}
