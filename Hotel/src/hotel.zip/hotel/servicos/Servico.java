package hotel.servicos;

public interface Servico {
    double calculaPreco();
    String getDescricao();
}
