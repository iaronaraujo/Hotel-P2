package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 * Um quarto extensivel eh aquele que aceita camas extra
 */
public abstract class QuartoExtensivel extends Quarto implements Serializable {
	private int qCamasExtras;
	private final double precoCamaExtra;
	private final int MAXIMO_CAMAS_EXTRA = 2;
	
	/**
	 * Construtor
	 * @param qCamasExtras
	 * 			A quantidade de camas extra desejada pelo hospede
	 */
	public QuartoExtensivel(int capacidade, double preco, int qCamasExtras, double precoExtra)throws Exception{
		super(capacidade, preco);
		check(qCamasExtras);
		this.qCamasExtras = qCamasExtras;
		this.precoCamaExtra = precoExtra;
	}
	
	private void check(int qCamasExtras)throws Exception{
		if(qCamasExtras < 0 || qCamasExtras > MAXIMO_CAMAS_EXTRA) throw new Exception("Numero invalido. Maximo: 2, Minimo : 0");
	}
	/**
	 * 
	 * @return A quantidade de camas extra desejada pelo hospede
	 */
	public int getQCamasExtras(){
		return qCamasExtras;
	}
	
	/**
	 * Atualiza a quantidade de camas extra desejada pelo hospede
	 * @param Q
	 * 			A nova quantidade de camas extra desejada pelo hospede
	 */
	public void setQCamasExtras(int Q) throws Exception{
		check(Q);
		qCamasExtras = Q;
	}
	
	@Override
	public double getPrecoDiaria(){
		return super.getPrecoDiaria() + (qCamasExtras*precoCamaExtra);
	}
}
