package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class QuartoLuxoSimples extends QuartoExtensivel implements Serializable{
	public static String nomeQuarto = "Luxo simples";
	
	public QuartoLuxoSimples(int qCamasExtras)throws Exception{
		super(1, GerenciadorDePrecos.getPrecoLuxoSimples(), qCamasExtras, GerenciadorDePrecos.getPrecoCamaExtraLuxo());
	}
}
