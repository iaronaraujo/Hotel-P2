package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class QuartoLuxoTriplo extends Quarto implements Serializable{
	public static String nomeQuarto = "Luxo triplo";
	
	public QuartoLuxoTriplo(){
		super(3, GerenciadorDePrecos.getPrecoLuxoTriplo());
	}
}
