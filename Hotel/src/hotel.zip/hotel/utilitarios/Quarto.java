package hotel.utilitarios;

import java.io.Serializable;

public abstract class Quarto implements Serializable{
	private final int capacidade;
	private final double precoDiaria;
	
	public Quarto(int capacidade, double preco){
		/* Nao precisa lancar excecao, pois a capacidade sera constante
		 * e o preco vira de gerenciador
		 */
		this.capacidade = capacidade;
		precoDiaria = preco;
	}

	public int getCapacidade() {
		return capacidade;
	}

	public double getPrecoDiaria() {
		return precoDiaria;
	}


}
