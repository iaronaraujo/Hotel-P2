package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class QuartoExecutivoTriplo extends Quarto implements Serializable{
	public static String nomeQuarto = "Executivo triplo";
	
	public QuartoExecutivoTriplo(){
		super(3,GerenciadorDePrecos.getPrecoExecutivoTiplo());
	}
}
