package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class Opiniao implements Serializable{
	private String comentario;
	private double nota;
	
	/**
	 * Construtor
	 * @param comentario
	 * @param nota
	 * @throws Exception Caso a nota seja menor que 0 ou maior que 10
	 */
	public Opiniao(String comentario, double nota) throws Exception{
		check(nota);
		this.comentario = comentario;
		this.nota = nota;
	}
	
	private void check(double nota) throws Exception{
		if (nota < 0 || nota > 10) throw new Exception("A nota vai de 0 a 10!");
	}
	
	/**
	 * 
	 * @return O Comentario
	 */
	public String getComentario(){
		return comentario;
	}
	
	/**
	 * Atualiza o comentario
	 * @param novoComentario
	 * 			O novo comentario
	 */
	public void setComentario(String novoComentario){
		comentario = novoComentario;
	}
	
	/**
	 * 
	 * @return A nota
	 */
	public double getNota(){
		return nota;
	}
	
	/**
	 * Atualiza a nota
	 * @param novaNota
	 * 			A nova nota
	 * @throws Exception Caso a nota seja menor que 0 ou maior que 10
	 */
	public void setNota(double novaNota) throws Exception{
		check(novaNota);
		nota = novaNota;
	}
}
