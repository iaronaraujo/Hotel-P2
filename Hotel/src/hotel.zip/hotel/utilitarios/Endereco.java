package hotel.utilitarios;

import java.io.Serializable;

/** 
 * @author Iaron da Costa Araujo
 *
 */
public class Endereco implements Serializable{
	private String pais;
	private String cidade;
	private String rua;
	private int num;
	private boolean isApartamento;
	private int numApt;
	
	
	/**
	 * Construtor
	 * 
	 * @param pais
	 * 			O pais
	 * @param cidade
	 * 			A cidade
	 * @param rua
	 * 			A rua
	 * @param num
	 * 			O numero da residencia
	 * @param numApt
	 * 			O numero do apartamento. Caso seja -1, significa que o endereco
	 * 			nao eh de apartamento.
	 */
	public Endereco(String pais, String cidade, String rua, int num, int numApt) throws  Exception {
		check(pais, cidade, rua, num, numApt);
		this.pais = pais;
		this.cidade = cidade;
		this.rua = rua;
		this.num = num;
		if (numApt == -1) {
			this.numApt = -1;
			this.isApartamento = false;
		} else {
			this.numApt = numApt;
			this.isApartamento = true;
		}
	}
	
	/**
	 * Construtor
	 * 
	 * @param pais
	 * 			O pais
	 * @param cidade
	 * 			A cidade
	 * @param rua
	 * 			A rua
	 * @param num
	 * 			O numero da residencia
	 */
	public Endereco(String pais, String cidade, String rua, int num)throws Exception{
		this(pais, cidade, rua, num, -1);
	}
	
	private void check(String pais, String cidade, String rua, int num, int numApt)throws Exception{
		if (pais == null || pais.equals("")) throw new Exception("Pais invalido!");
		if (cidade == null || cidade.equals("")) throw new Exception("Cidade invalida!");
		if (rua == null || rua.equals("")) throw new Exception("Rua invalida!");
		if (num < -1) throw new Exception("Numero de residencia invalido");
		if (numApt < -1) throw new Exception("Numero de apartamento invalido");
		
		
	}
	
	/**
	 * 
	 * @return O pais
	 */
	public String getPais(){
		return pais;
	}
	
	/**
	 * Atualiza o pais
	 * @param novoPais
	 * 			O novo pais
	 */
	public void setPais(String novoPais){
		pais = novoPais;
	}
	
	/**
	 * 
	 * @return A cidade
	 */
	public String getCidade(){
		return cidade;
	}
	
	/**
	 * Atualiza a cidade
	 * @param novaCidade
	 * 			A nova cidade
	 */
	public void setCidade(String novaCidade){
		cidade = novaCidade;
	}
	
	/**
	 * 
	 * @return A rua
	 */
	public String getRua(){
		return rua;
	}
	
	/**
	 * Atualiza a rua
	 * @param novaRua
	 * 			A nova rua
	 */
	public void setRua(String novaRua){
		rua = novaRua;
	}
	
	/**
	 * 
	 * @return O numero da residencia
	 */
	public int getNum(){
		return num;
	}
	
	/**
	 * Atualiza o novo numero da residencia
	 * @param novoNum
	 * 		O novo numero da residencia
	 */
	public void setNum(int novoNum){
		num = novoNum;
	}
	
	/**
	 * 
	 * @return Se eh apartamento
	 */
	public boolean getIsApartamento(){
		return isApartamento;
	}
	
	// ==============================================================
	/* Seguinte, eu mudei essa parte mas acho q talvez ela nao fique 
	 * assim no final. Eu tirei o set numApt pq eu achei que seria 
	 * melhor se so os enderencos que tem o isApartamento == true
	 * pudessem mudar o numero do apartamento. A, e quando o numero
	 * do apt eh -1 isso quer dizer que nao eh apartamento.
	 */
	
	/**
	 * Muda o estado da residencia, identificando, agora, que eh um apartamento
	 * @param numApt
	 * 			Numero do apartamento
	 */
	public void ehApartamento(int numApt){
		isApartamento = true;
		this.numApt = numApt;
	}
	
	/**
	 * Muda o estado da residencia, identificando, agora, que nao eh um apartamento
	 */
	public void naoEhApartamento(){
		isApartamento = false;
		this.numApt = -1;
	}
	
	// ==============================================================
	/**
	 * 
	 * @return O numero do apartamento. O -1 significa que a residencia nao eh um apartamento
	 */
	public int getNumApt(){
		return numApt;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Endereco))
			return false;
		
		Endereco end = (Endereco) obj;
		
		if(	end.getCidade().equals(cidade) &&
				end.getNum() == num &&
				end.getNumApt() == numApt &&
				end.getPais().equals(pais) &&
				end.getRua().equals(rua)) { 
			return true; 
		}
		
		return false;
	}
	
}
