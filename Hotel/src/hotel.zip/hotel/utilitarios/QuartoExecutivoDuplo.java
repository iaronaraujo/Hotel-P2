package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class QuartoExecutivoDuplo extends QuartoExtensivel implements Serializable{
	public static String nomeQuarto = "Executivo duplo";
	
	public QuartoExecutivoDuplo(int qCamasExtras)throws Exception{
		super(2, GerenciadorDePrecos.getPrecoExecutivoDuplo(), qCamasExtras, GerenciadorDePrecos.getPrecoCamaExtraExecutivo());
	}
}
