package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class QuartoPresidencial extends Quarto implements Serializable {	
	public static String nomeQuarto = "Presidencial";
	
	public QuartoPresidencial(){
		super(4, GerenciadorDePrecos.getPrecoPresidencial());
	}
}
