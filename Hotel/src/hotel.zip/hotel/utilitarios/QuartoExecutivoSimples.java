package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class QuartoExecutivoSimples extends QuartoExtensivel implements Serializable{	
	public static String nomeQuarto = "Executivo Simples";
	
	public QuartoExecutivoSimples(int qCamasExtras)throws Exception{
		super(1, GerenciadorDePrecos.getPrecoExecutivoSimples(), qCamasExtras, GerenciadorDePrecos.getPrecoCamaExtraExecutivo());
	}
}
