package hotel.utilitarios;

import java.io.Serializable;

/**
 * 
 * @author Iaron da Costa Araujo
 *
 */
public class CarroExecutivo extends Carro implements Serializable{
	public static final String nomeServico = "Executivo";
	
	public CarroExecutivo(){
		super(GerenciadorDePrecos.getPrecoDeDiariaCarroExecutivo());
	}

}
