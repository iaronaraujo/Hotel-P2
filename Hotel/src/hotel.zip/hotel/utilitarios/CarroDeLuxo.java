package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class CarroDeLuxo extends Carro implements Serializable{
	public static final String nomeServico = "Luxo";
		
	public CarroDeLuxo(){
		super(GerenciadorDePrecos.getPrecoDeDiariaCarroDeLuxo());
	}
}
