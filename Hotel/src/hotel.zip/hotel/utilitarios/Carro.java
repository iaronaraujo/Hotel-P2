package hotel.utilitarios;

public abstract class Carro {
	private double precoDiaria;
	
	

	public Carro(double preco){
		// Nao precisa verificar caso o preco seja negativo
		// pois ele sera recebido pelo Gerenciador de precos
		// ou seja, nao cabe a carro verificar se o preco eh
		// valido, mas sim ao gerenciador.
		precoDiaria = preco;
	}
	/**
	 * @return O preco da diaria do carro de luxo na epoca que foi alugado
	 */
	public double precoDeAluguel() {
		return precoDiaria;
	}

}
