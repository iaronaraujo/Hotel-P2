package hotel.utilitarios;

import java.io.Serializable;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class QuartoLuxoDuplo extends QuartoExtensivel implements Serializable{
	public static String nomeQuarto = "Luxo duplo";
	
	public QuartoLuxoDuplo(int qCamasExtras)throws Exception{
		super(2, GerenciadorDePrecos.getPrecoLuxoDuplo(), qCamasExtras, GerenciadorDePrecos.getPrecoCamaExtraLuxo());
	}
}
