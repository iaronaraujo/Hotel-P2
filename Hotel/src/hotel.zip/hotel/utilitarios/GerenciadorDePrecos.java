package hotel.utilitarios;

import java.io.Serializable;

public class GerenciadorDePrecos implements Serializable {
	private static double precoExecutivoTiplo;
	private static double precoExecutivoDuplo;
	private static double precoExecutivoSimples;
	private static double precoLuxoTriplo;
	private static double precoLuxoDuplo;
	private static double precoLuxoSimples;
	private static double precoPresidencial;
	private static double precoDeSeguro;
	private static double precoDeTanqueCheio;
	private static double precoDeDiariaCarroDeLuxo;
	private static double precoDeDiariaCarroExecutivo;
	private static double precoBabysitHoraNormal;
	private static double precoCamaExtraExecutivo;
	private static double precoCamaExtraLuxo;
	
	public static double getPrecoExecutivoTiplo() {
		return precoExecutivoTiplo;
	}
	public static void setPrecoExecutivoTiplo(double preco) throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoExecutivoTiplo = preco;
	}
	public static double getPrecoExecutivoDuplo() {
		return precoExecutivoDuplo;
	}
	public static void setPrecoExecutivoDuplo(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoExecutivoDuplo = preco;
	}
	public static double getPrecoExecutivoSimples() {
		return precoExecutivoSimples;
	}
	public static void setPrecoExecutivoSimples(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoExecutivoSimples = preco;
	}
	public static double getPrecoLuxoTriplo() {
		return precoLuxoTriplo;
	}
	public static void setPrecoLuxoTriplo(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoLuxoTriplo = preco;
	}
	public static double getPrecoLuxoDuplo() {
		return precoLuxoDuplo;
	}
	public static void setPrecoLuxoDuplo(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoLuxoDuplo = preco;
	}
	public static double getPrecoLuxoSimples() {
		return precoLuxoSimples;
	}
	public static void setPrecoLuxoSimples(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoLuxoSimples = preco;
	}
	public static double getPrecoPresidencial() {
		return precoPresidencial;
	}
	public static void setPrecoPresidencial(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoPresidencial = preco;
	}
	public static double getPrecoDeSeguro() {
		return precoDeSeguro;
	}
	public static void setPrecoDeSeguro(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoDeSeguro = preco;
	}
	public static double getPrecoDeTanqueCheio() {
		return precoDeTanqueCheio;
	}
	public static void setPrecoDeTanqueCheio(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoDeTanqueCheio = preco;
	}
	public static double getPrecoDeDiariaCarroDeLuxo() {
		return precoDeDiariaCarroDeLuxo;
	}
	public static void setPrecoDeDiariaCarroDeLuxo(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoDeDiariaCarroDeLuxo = preco;
	}
	public static double getPrecoDeDiariaCarroExecutivo() {
		return precoDeDiariaCarroExecutivo;
	}
	public static void setPrecoDeDiariaCarroExecutivo(
			double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoDeDiariaCarroExecutivo = preco;
	}
	public static double getPrecoBabysitHoraNormal() {
		return precoBabysitHoraNormal;
	}
	public static void setPrecoBabysitHoraNormal(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoBabysitHoraNormal = preco;
	}
	public static double getPrecoBabysitHoraDobrada() {
		return precoBabysitHoraNormal * 2;
	}
	public static double getPrecoCamaExtraExecutivo() {
		return precoCamaExtraExecutivo;
	}
	public static void setPrecoCamaExtraExecutivo(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoCamaExtraExecutivo = preco;
	}
	public static double getPrecoCamaExtraLuxo() {
		return precoCamaExtraLuxo;
	}
	public static void setPrecoCamaExtraLuxo(double preco)  throws Exception{
		if(preco < 0) throw new Exception("O valor nao pode ser negativo!");
		GerenciadorDePrecos.precoCamaExtraLuxo = preco;
	}
	
}
