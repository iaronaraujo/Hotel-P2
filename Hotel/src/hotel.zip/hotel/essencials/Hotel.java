package hotel.essencials;

import hotel.servicos.AluguelDeCarro;
import hotel.servicos.Babysitting;
import hotel.servicos.DiariaQuarto;
import hotel.servicos.Refeicao;
import hotel.servicos.Servico;
import hotel.utilitarios.CarroDeLuxo;
import hotel.utilitarios.Opiniao;
import hotel.utilitarios.QuartoLuxoSimples;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luiz
 */
public class Hotel implements Serializable{
	private static final long serialVersionUID = 157896503001L;;
	public static final String DEFAULT_STRING = "*##d*$*E*$*f*$*A*$*u*$*L*$*t##*";
	public static final int DEFAULT_INT = 1;
	public static final int CPF_TAMANHO = 14;
	
    private String nomeHotel;
    private String localidade;
    private final List<Opiniao> opinioes;
    private final List<Contrato> contratos;
    private final List<Servico> servicosOferecidos;

    /**
     * @param nomeHotel Nome do Hotel a ser inicializado
     * @param localidade Localidade do hotel a ser inicializado
     * @throws Exception Para nomeHotel nulo ou vazio Para localidade nula ou
     * vazia
     */
    public Hotel(String nomeHotel, String localidade) throws Exception {

        if (nomeHotel == null || nomeHotel.equals("")) {
            throw new Exception("Nome do hotel invalido");
        }

        if (localidade == null || localidade.equals("")) {
            throw new Exception("Localidade invalida");
        }

        this.nomeHotel = nomeHotel;
        this.localidade = localidade;
        opinioes = new ArrayList<Opiniao>();
        contratos = new ArrayList<Contrato>();
        servicosOferecidos = new ArrayList<Servico>();
        
        // Povoando
        servicosOferecidos.add(new Babysitting(1,1, "Default"));
        servicosOferecidos.add(new AluguelDeCarro(new CarroDeLuxo(), 1, true, true, "Default"));
        servicosOferecidos.add(new Refeicao(1, "Default"));
        servicosOferecidos.add(new DiariaQuarto(new QuartoLuxoSimples(1), 1, "Default"));
    }

    /**
     * Adiciona contrato passado a lista de contratos
     *
     * @param contrato
     * @return boolean Relativo ao sucesso da operação
     * @throws Exception Para contrato nulo
     */
    public boolean checkIn(Contrato contrato) throws Exception {

        if (contrato == null) {
            throw new Exception("Contrato invalido");
        }

        return contratos.add(contrato);
    }

    /**
     * Metodo responsável pela inativacao de um contrato
     *
     * @param contrato objeto do tipo Contrato a ser inativado
     * @return boolean Relativo ao sucesso do checkout
     * @throws Exception Para contrato nulo
     */
    public boolean checkOut(Contrato contrato) throws Exception {

        if (contrato == null) {
            throw new Exception("Contrato invalido");
        }

        for (Contrato c : contratos) {

            if (c.equals(contrato)) {
                c.setEstadoDoContrato(false);
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @param contrato
     * @return
     * @throws Exception Para contrato nulo
     */
    public Contrato pesquisaContrato(Contrato contrato) throws Exception {

        if (contrato == null) {
            throw new Exception("Contrato invalido");
        }

        for (Contrato c : contratos) {
            if (c.equals(contrato)) {
                return c;
            }
        }
        return null;
    }

    /**
     * Adiciona servico passado na lista de servicos oferecidos
     *
     * @param servico
     * @return Boolean Retorna true para operação realizada e false para
     * operação falha
     * @throws Exception Para servico nulo
     */
    public boolean adicionaServico(Servico servico) throws Exception {

        if (servico == null) {
            throw new Exception("Servico invalido");
        }

        return servicosOferecidos.add(servico);
    }
    
    public boolean removeServico(Servico servico) throws Exception{
		
    	if (servico == null) throw new Exception("Servico invalido");
		
    	return servicosOferecidos.remove(servico);
	}

    /**
     * Pesquisa servico passado na lista de servicos oferecidos
     *
     * @param servico Objeto do tipo Servico a ser pesquisado
     * @return Servico Servico oferecido no caso de estar na lista e null no
     * caso de que não esteja
     * @throws Exception
     */
    public Servico pesquisaServico(Servico servico) throws Exception {
        if (servico == null) {
            throw new Exception("Servico invalido");
        }

        for (Servico s : servicosOferecidos) {
            if (s.equals(servico)) {
                return s;
            }
        }

        return null;
    }

    /**
     * Adiciona opiniao passada a lista de opinioes
     *
     * @param Opiniao opin
     * @return Boolean Relativo ao sucesso da operacao
     * @throws Exception Para opiniao nula
     */
    public boolean adicionaOpiniao(Opiniao opin) throws Exception {

        if (opin == null) {
            throw new Exception("Opiniao invalida");
        }

        return opinioes.add(opin);
    }

    /**
     * Pesquisa se hospede está hospedado no hotel
     *
     * @param hosp Hospede a ser buscado
     * @return boolean No caso do hospede estar hospedado no hotel
     * @throws Exception Para hospede nulo
     */
    public boolean pesquisaHospede(Hospede hosp) throws Exception {
        if (hosp == null) {
            throw new Exception("Hospede invalido");
        }

        for (Contrato c : contratos) {
            for (Hospede h : c.getListaDeHospedesAssociados()) {
            	if (h.equals(hosp) && c.getEstadoDoContrato()) return true;
            }
        }

        return false;
    }

    /**
     * Calcula a media de aceitação do hotel atraves das opiniões
     * @return double media
     */
    public double mediaDeAceitacao() {
        double total = 0;
        if (opinioes.isEmpty()) return 0.0;
        for(Opiniao o : opinioes){
            total += o.getNota();
        }
        double media = total / opinioes.size();
        
        return media;
    }
    
    public String geraRelatorioServicosDisponiveis() {
        return "";
    }

    public String geraRelatorioServicosMaisContratados() {
        return "";
    }

    public String geraRelatorioFaturamentoMensal() {
        return "";
    }

    public String geraRelatorioContratosAbertos() {
        return "";
    }

    /**
     *
     * @return Localidade do hotel
     */
    public String getLocalidade() {
        return localidade;
    }

    /**
     *
     * @return retorna nome do hotel
     */
    public String getNomeHotel() {
        return nomeHotel;
    }

    /**
     * Atualiza a localidade do hotel
     *
     * @param localidade
     * @throws Exception Para Localidade nula ou vazia
     */
    public void setLocalidade(String localidade) throws Exception {

        if (localidade == null || localidade.equals("")) {
            throw new Exception("Localidade invalida");
        }

        this.localidade = localidade;
    }

    /**
     * Atualiza nome do hotel
     *
     * @param nomeHotel
     * @throws Exception Para nome do hotel nulo ou vazio
     */
    public void setNomeHotel(String nomeHotel) throws Exception {
        if (nomeHotel.equals("") || nomeHotel == null) {
            throw new Exception("Nome do hotel invalido");
        }
        this.nomeHotel = nomeHotel;
    }
    
    /**
     * Retorna lista de servicos oferecidos
     * @return List<Servico>
     */
    public List<Servico> getServicosOferecidos() {
		return servicosOferecidos;
	}
    
    /**
     * Retorna lista de contratos estabelecidos 
     * @return List<Contrato>
     */
    public List<Contrato> getContratos() throws Exception{
    	/*List<Contrato> contratosCopia = new ArrayList<Contrato>();
    	for (Contrato contrato : contratos) {
    		contratosCopia.add(new Contrato(contrato));
    	}*/
    	
		return contratos;
	}
    
    /**
     * Retorna lista de opinioes recebidas
     * @return List<Opiniao>
     */
    public List<Opiniao> getOpinioes() {
		return opinioes;
	}
}
