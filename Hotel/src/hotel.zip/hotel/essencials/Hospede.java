package hotel.essencials;

// Pra que serve o import servicos e o import List?
import hotel.utilitarios.Endereco;

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class Hospede implements Serializable{
	
    private String nome;
    private GregorianCalendar dataDeNascimento;
    private Endereco enderecoDeResidencia;
    private String cpf;

    /**
     * Construtor
     *
     * @param nome Nome do hospede
     * @param cpf CPF do hospede
     * @param dataDeNascimento Data de nascimento do hospede
     * @param enderecoDeResidencia Endereco do hospede
     * @throws Exception Caso o nome seja vazio ou o cpf negativo
     */
    public Hospede(String nome, String cpf, GregorianCalendar dataDeNascimento, Endereco enderecoDeResidencia) throws Exception {
        check(nome, cpf, dataDeNascimento);
        this.nome = nome;
        this.cpf = cpf;
        this.dataDeNascimento = dataDeNascimento;
        this.enderecoDeResidencia = enderecoDeResidencia;
    }
    
    /**
     * Construtor
     * 
     * @param nome Nome do hospede
     * @param dataDeNascimento Data de nascimento do hospede
     * @throws Exception Caso o nome seja vazio
     */
    public Hospede(String nome, GregorianCalendar dataDeNascimento) throws Exception {
    	this(nome, Hotel.DEFAULT_STRING, dataDeNascimento, new Endereco(Hotel.DEFAULT_STRING, Hotel.DEFAULT_STRING, Hotel.DEFAULT_STRING, Hotel.DEFAULT_INT, Hotel.DEFAULT_INT));
    }
    
    private void check(String nome, String cpf, GregorianCalendar dataDeNascimento) throws Exception {
        if (nome == null || nome.equals("") || nome.equals(" ")) {
            throw new Exception("Nome nao pode ser vazio");
        }
        
        if (cpf == null || cpf.equals("") || cpf.length() < Hotel.CPF_TAMANHO || cpf.charAt(13) == ' ') { // Mudar mensagem
            throw new Exception("CPF nao pode ser nulo");
        }
        
        if (dataDeNascimento == null) {
        	throw new Exception("Data de nascimento nao pode ser nula");
        }
    }

    /**
     *
     * @return nome do hospede
     */
    public String getNome() {
        return nome;
    }
    
    /**
     * Atualiza o nome do hospede
     * 
     * @param nome Novo nome
     */
    public void setNome(String nome) throws Exception {
    	if (nome == null || nome.equals("") || nome.equals(" ")) {
            throw new Exception("Nome nao pode ser vazio");
        }
    	
		this.nome = nome;
	}

	/**
     *
     * @return Data de nascimento em forma de gregorian calendar
     */
    public GregorianCalendar getDataDeNascimento() {
        // Eh bom testar isso com MUITO cuidado
        GregorianCalendar data = new GregorianCalendar(dataDeNascimento.get(Calendar.YEAR), dataDeNascimento.get(Calendar.MONTH), dataDeNascimento.get(Calendar.DAY_OF_MONTH));
        return data;
    }
    
    /**
     * Atualiza a data de nascimento do hospede
     * 
     * @param dataDeNascimento Nova data de nascimento
     */
	public void setDataDeNascimento(GregorianCalendar dataDeNascimento) throws Exception {
		if (dataDeNascimento == null) {
        	throw new Exception("Data de nascimento nao pode ser nula");
        }
		
		this.dataDeNascimento = dataDeNascimento;
	}

    /**
     *
     * @return Endereco da residencia do hospede
     */
    public Endereco getEnderecoDeResidencia() throws Exception {
        Endereco endereco = new Endereco(enderecoDeResidencia.getPais(), enderecoDeResidencia.getCidade(), enderecoDeResidencia.getRua(), enderecoDeResidencia.getNum(), enderecoDeResidencia.getNumApt());
        return endereco;
    }
    
    /**
	 * Atualiza o endereco de residencia do hospede
	 * 
	 * @param enderecoDeResidencia Novo endereco de residencia
	 */
	public void setEnderecoDeResidencia(Endereco enderecoDeResidencia) {
		this.enderecoDeResidencia = enderecoDeResidencia;
	}

    /**
     *
     * @return CPF do hospede
     */
    public String getCpf() {
        return cpf;
    }
    
    /**
     * Atualiza o cpf do hospede
     * 
     * @param cpf Novo cpf
     */
	public void setCpf(String cpf) throws Exception{
		if (cpf.equals("") || cpf.length() < Hotel.CPF_TAMANHO || cpf.charAt(13) == ' ') {
            throw new Exception("CPF nao pode ser nulo");
        }
		
		this.cpf = cpf;
	}

    /**
     * Compara os hospedes de acordo com nome, cpf, dataDeNascimento e
     * enderecoDeResidencia
     *
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Hospede)) {
            return false;
        }
        Hospede hospTemp = (Hospede) obj;
        if (hospTemp.getNome().equals(nome)){
                return true;
        } else{
        return false;
        }
    }
}
