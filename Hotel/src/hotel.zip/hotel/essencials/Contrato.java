package hotel.essencials;

import hotel.estrategia.EstrategiaDeTarifa;
import hotel.servicos.Servico;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author Iaron da Costa Araujo
 *
 */
public class Contrato implements Serializable{
    private List<Hospede> listaDeHospedesAssociados;
    public List<Servico> listaDeServicosContratados;
    private GregorianCalendar dataInicial;
    private GregorianCalendar dataFinal;
    private EstrategiaDeTarifa tipoDeTarifa;
    private long numCartaoDeCredito;
    private boolean estadoDoContrato;
    private List<Servico> servicosOferecidos;
    private final String cpfContratante;

    /**
     * Construtor
     *
     * @param representante Hospede representante do contrato
     * @param dataInicial Data do check in
     * @param dataFinal Data do check out
     * @param tipoDeTarifa Estrategia de tarifacao
     * @param numCartaoDeCredito Numero do cartao de credito usado para pagar
     * @param servicosOferecidos A lista com os servicos disponiveis do hotel
     */
    public Contrato(Hospede representante, GregorianCalendar dataInicial, GregorianCalendar dataFinal, EstrategiaDeTarifa tipoDeTarifa, long numCartaoDeCredito, List<Servico> servicosOferecidos) throws Exception {
        check(representante, dataInicial, dataFinal, tipoDeTarifa, numCartaoDeCredito);
        listaDeHospedesAssociados = new ArrayList<Hospede>();
        listaDeServicosContratados = new ArrayList<Servico>();
        listaDeHospedesAssociados.add(representante);
        this.dataInicial = dataInicial;
        // vai ficar assim mesmo ou a gente muda dataFinal para quantidadeDeDias?
        this.dataFinal = dataFinal;
        this.tipoDeTarifa = tipoDeTarifa;
        this.numCartaoDeCredito = numCartaoDeCredito;
        this.servicosOferecidos = servicosOferecidos;
        this.cpfContratante = representante.getCpf();
        this.estadoDoContrato = true;
    }
    
    /**
     * Construtor de copia
     * 
     * @param contrato O contrato a ser copiado
     * @throws Exception Se o contrato for construido incorretamente 
     */
    public Contrato(Contrato contrato) throws Exception {
    	this(contrato.getListaDeHospedesAssociados().get(0), contrato.getDataInicial(), contrato.getDataFinal(), contrato.getTipoDeTarifa(), contrato.getNumCartaoDeCredito(), contrato.getServicosOferecidos());
    }

    private void check(Hospede representante, GregorianCalendar dataInicial, GregorianCalendar dataFinal, EstrategiaDeTarifa tipoDeTarifa, long numCartaoDeCredito) throws Exception {
    	if(representante == null) throw new Exception("Hospede invalido");
        if (representante.getCpf().equals("") || representante.getCpf().length() < Hotel.CPF_TAMANHO || representante.getCpf().charAt(13) == ' ' || representante.getCpf().equals(Hotel.DEFAULT_STRING)) {
            throw new Exception("O CPF do representante eh obrigatorio"); // Mudar mensagem
        }
        if (dataInicial == null){
        	throw new Exception("Data inicial invalida");
        }
        if (dataFinal == null){
        	throw new Exception("Data final invalida");
        }
        if (dataInicial.compareTo(dataFinal) >= 0){
        	throw new Exception("As datas passadas devem ser distintas"); // Mudar mensagem
        }
        if (tipoDeTarifa == null){
        	throw new Exception("Estrategia de tarifa invalida");
        }
        if (numCartaoDeCredito <= 0){
        	throw new Exception("Cartão de credito invalido");
        }
    }

    /**
     * Usado no check out. Calcula o quanto deve ser pago.
     *
     * @return Total gasto
     */
    public double calculaTotalGasto() {
        // A estrategia era pra entrar aqui? ***** botei(luiz)
        double totalGasto = 0;
        double contaCheckout = 0;
        for (Servico s : listaDeServicosContratados) {
            totalGasto += s.calculaPreco();
        }
        try {
            contaCheckout = tipoDeTarifa.calculaTotalGasto(totalGasto);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return contaCheckout;
    }

    /**
     * Adiciona um novo hospede ao contrato, caso ele ja nao esteja nele.
     *
     * @param hospede Novo hospede
     * @return Se adicionou
     */
    public boolean adicionaHospede(Hospede hospede) {
        // Nao podera adicionar um novo hospede caso ele ja esteja na lista.
        if (listaDeHospedesAssociados.contains(hospede)) {
            return false;
        }
        listaDeHospedesAssociados.add(hospede);
        System.out.println("Adicionou");
        return true;
    }

    /**
     * Remove um hospede do contrato, caso ele esteja nele.
     *
     * @param hospede Hospede a ser removido.
     * @return Se removeu o hospede.
     */
    public boolean removeHospede(Hospede hospede) throws Exception {

        if (hospede.getCpf() == cpfContratante) {
            throw new Exception("Hospede contratante nao pode ser removido"); // luiz esteve aki xD
        }
        if (listaDeHospedesAssociados.contains(hospede)) {
            listaDeHospedesAssociados.remove(hospede);
            return true;
        }
        return false;
    }

	// ========================================================
	/* OK, OK, essa vai ser a parte emocionante... como mulesta 
     * eu faço isso? pq tipo, no caso da babyssiter que tem hor
     * ario, como que eu vou verificar se tal serviço ta na lis
     * ta? Pq com carro colocar gasolina e seguro eh tipo um ex
     * tra, da pra fazer com qualquer carro ne? Refeicao tambem
     * eh simples, so abrir o cardapio, vc vai dando check e tu
     * do fica de boa, mas e DiariaQuarto e Babysitting que dep
     * ende de horario??? Tipo, quarto nem tanto pq n tem reser
     * va ne? tipo, quando vc for fazer o contrato, assim que v
     * c fizer vc vai ocupar o quarto, entao acho q n tem muito
     * problema... mas e babysitting? A gente bota pra o horari
     * o inicial da babys]sitter ser assim que o servico for pe
     * dido? Como exatamente vai ser isso? Ah e outra coisa, no
     * s que tem tempo, eles vao ser removidos quando acabar o
     * tempo? Se sim, como vamos efetuar o custo dele na hora d
     * o check out ja que ele nao vai estar na lista?
     */
    /**
     * Adiciona um novo servico ao contrato, caso ele esteja disponivel.
     *
     * @param servico O servico a ser adicionado
     * @return Se adicionou o servico
     */
    public boolean adicionaServico(Servico servico) {
    	for (Servico s : servicosOferecidos) {
    		if (s.getClass().getName().equals(servico.getClass().getName())) {
    			listaDeServicosContratados.add(servico);
    			servicosOferecidos.remove(servico);
    			return true;
    		}
    	}
        return false;
    }

    /**
     * Remove um servico, caso ele esteja na lista de servicos contratados
     *
     * @param servico O servico a ser removido
     * @return Se removeu o servico
     */
    public boolean removeServico(Servico servico) {
        if (listaDeServicosContratados.contains(servico)) {
            servicosOferecidos.add(servico);
            listaDeServicosContratados.remove(servico);// Axo q isso aki tem q ser alterado dps agent ve..
            return true;
        }
        return false;
    }
	// ========================================================

    /**
     * Atualiaza o estado do contrato
     *
     * @param novoEstado Novo estado
     */
    public void setEstadoDoContrato(boolean novoEstado) {
        this.estadoDoContrato = novoEstado;
    }

    /**
     *
     * @return Estado do contrato
     */
    public boolean getEstadoDoContrato() {
        return estadoDoContrato;
    }

    /**
     * Atualiza as informacoes de um hospede caso ele exista no contrato
     *
     * @param hospedeMudar Hospede a ser mudado
     * @param novasInformacoes Novas informacoes
     * @return Se mudou as informacoes
     */
    public boolean atualizaHospede(Hospede hospedeMudar, Hospede novasInformacoes) {
        for (Hospede h : listaDeHospedesAssociados) {
        		if(h.equals(hospedeMudar)){
        			int i = listaDeHospedesAssociados.indexOf(h);
        			listaDeHospedesAssociados.set(i, novasInformacoes);
        			return true;
        	}
        }
        return false;
    }

    /**
     *
     * @return Lista de Hospedes Associados ao contrato
     */
    public List<Hospede> getListaDeHospedesAssociados() throws Exception {
    	/*List<Hospede> listaDeHospedesCopia = new ArrayList<Hospede>();
    	for (Hospede hospede : listaDeHospedesAssociados) {
    		listaDeHospedesCopia.add(new Hospede(hospede));
    	}
    	System.out.println(listaDeHospedesCopia.size() + " DE CONTRATO");*/
        return listaDeHospedesAssociados;
    }

    /**
     * Troca a lista de hospedes associados
     *
     * @param listaDeHospedesAssociados A nova lista de hospedes associados
     */
    public void setListaDeHospedesAssociados(List<Hospede> listaDeHospedesAssociados) {
        this.listaDeHospedesAssociados = listaDeHospedesAssociados;
    }

    /**
     *
     * @return A lista de servicos contratados
     */
    public List<Servico> getListaDeServicosContratados() {
        return listaDeServicosContratados; // Provavelmente eh isso q tem q organizar melhor... 
                                           // os servicos tem q tar de acordo com a lista de hotel tbm
    }

    /**
     * Troca a lista de servicos contratados
     *
     * @param listaDeServicosContratados A nova lista de servicos contratados
     */
    public void setListaDeServicosContratados(List<Servico> listaDeServicosContratados) {
        this.listaDeServicosContratados = listaDeServicosContratados;
    }

    /**
     *
     * @return A data do check in
     */
    public GregorianCalendar getDataInicial() {
        GregorianCalendar data = new GregorianCalendar(dataInicial.get(Calendar.YEAR), dataInicial.get(Calendar.MONTH), dataInicial.get(Calendar.DAY_OF_MONTH));
        return data;
    }

    /**
     * Muda a data do check in
     *
     * @param dataInicial A nova data do check in
     */
    public void setDataInicial(GregorianCalendar dataInicial) {
        this.dataInicial = dataInicial;
    }

    /**
     *
     * @return A data do check out
     */
    public GregorianCalendar getDataFinal() {
        GregorianCalendar data = new GregorianCalendar(dataFinal.get(Calendar.YEAR), dataFinal.get(Calendar.MONTH), dataFinal.get(Calendar.DAY_OF_MONTH));
        return data;
    }

    /**
     * Muda a data do check out
     *
     * @param dataFinal A nova data do check out
     */
    public void setDataFinal(GregorianCalendar dataFinal) {
        this.dataFinal = dataFinal;
    }

    /**
     *
     * @return O tipo de tarifacao
     */
    public EstrategiaDeTarifa getTipoDeTarifa() {
        return tipoDeTarifa;
    }

    /**
     * Altera o tipo de tarifacao
     *
     * @param tipoDeTarifa O novo tipo de tarifacao
     */
    public void setTipoDeTarifa(EstrategiaDeTarifa tipoDeTarifa) {
        this.tipoDeTarifa = tipoDeTarifa;
    }

    /**
     *
     * @return Lista de servicos oferecidos
     */
    public List<Servico> getServicosOferecidos() {
        return servicosOferecidos;
    }

    /**
     * Troca a lista de servicos oferecidos
     *
     * @param servicosOferecidos A nova lista de servicos oferecidos
     */
    public void setServicosOferecidos(List<Servico> servicosOferecidos) {
        this.servicosOferecidos = servicosOferecidos;
    }

    /**
     *
     * @return numero do cartao de credito
     */
    public long getNumCartaoDeCredito() {
        return numCartaoDeCredito;
    }

    /**
     * Atualiza o numero do cartao de credito
     *
     * @param novoNumero O novo numero
     */
    public void setNumCartaoDeCredito(long novoNumero) {
        numCartaoDeCredito = novoNumero;
    }

    /**
     * Retorna o cpf do hospede responsavel pelo contrato
     *
     * @return cpfContratante
     */
    public String getCpfContratante() {
        return cpfContratante;
    }
    
   /**
    * Pesquisa um hospede na lista de hospedes associados
    * 
    * @param hospede O hospede a ser pesquisado
    * @return O hospede achado na lista
    * @throws Exception Caso o hospede passado como parâmetro seja null
    */
   public Hospede pesquisaHospede(Hospede hospede) throws Exception {

       if (hospede == null) {
           throw new Exception("Contrato invalido");
       }

       for (Hospede h : listaDeHospedesAssociados) {
           if (h.equals(hospede)) {
               return h;
           }
       }
       return null;
   }


    /**
     * Compara os contratos analizando dataInicial, dataFinal,
     * numCartaoDeCredito e cpfContratante(atributos de Hospede)
     *
     * @param contr Contrato a ser comparado
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {

        if (!(obj instanceof Contrato)) {
            return false;
        }

        Contrato contratoTemp = (Contrato) obj;
  
        if (contratoTemp.getDataFinal().equals(dataFinal)
            && contratoTemp.getDataInicial().equals(dataInicial)
            && contratoTemp.getCpfContratante().equals(cpfContratante)) {
        	
            return true;
        }

        return false;
    }
}
